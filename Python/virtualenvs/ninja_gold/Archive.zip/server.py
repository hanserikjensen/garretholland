from flask import Flask, render_template, redirect, request, session, flash
import random

app = Flask(__name__)
app.secret_key = 'KeepItSecretKeepItSafe'
@app.route('/')
def index():
    return render_template('index.html')
@app.route('/process_money', methods=['POST'])
def process():
    session['gold'] = 0
    session['gold'] = str(session['gold'])

    # session['log'] = []

    if request.form['type'] == 'submit':
        if request.form['building'] == 'farm':
            session['gold'] += random.randrange(10, 20)
            print str(session['gold'])
            # session['log'].append('yay gold')
        if request.form['building'] == 'cave':
            session['gold'] += random.randrange(5, 10)
        if request.form['building'] == 'house':
            session['gold'] += random.randrange(2, 5)
        if request.form['building'] == 'house':
            session['gold'] += random.randrange(-50, 50)


        # return redirect('/')
        # if request.form.input['value'] == 'farm':
        #     session['gold'] += random.randrange(10, 20)
        # print session['gold']


    # session['cave'] = request.form['action']
    # session['house'] = request.form['action']
    # session['casino'] = request.form['action']

    return redirect('/')
# @app.route('/')
# def show_user():
#     return render_template('user.html', name='Jay', email='kpatel@codingdojo.com')

app.run(debug=True)
# WERKZEUG_DEBUG_PIN = off
